# NFL Free Research Lab

A free NFL forecasting and walk-forward validation starter. No betting placement.

## Setup

Requires Python 3.10+ and an internet connection for the initial fetch.

```bash
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
python engine.py all
streamlit run dashboard.py
```

The `fetch` command retrieves NFL schedules via nflreadpy, then `prepare` computes strictly prior-game rolling team features, and `walkforward` trains on earlier seasons to predict each later season. It saves CSVs under `data/`.

## Honest limitations

- No API key required. No odds ingestion, verified profitability, live predictions, or player-prop model yet.
- Rolling team statistics reset neither by season nor by roster changes; the model may be poorly calibrated in early weeks and for teams with changed personnel.
- Calibration is fit to in-sample training predictions, which is optimistic; upgrade to nested historical out-of-fold calibration before using estimated probabilities for value calculations.
- NFL tie games are excluded from win-probability calibration, but still included in margin regression.
- `spread_line` and `total_line` in schedule data may reflect closing lines, not available prices at prediction time. Do not use them as executable odds.
- Rest days are capped at 21; first games have a 7-day neutral default.
- Marginal margin and total standard deviations are rough uncertainty measures, not rigorous coverage-guaranteed intervals.
- No independent odds baseline, historical ROI, injury-aware forecasts, player props, quarter markets, or automatic wagering.
- Walk-forward uses prior full seasons, not weekly expanding refits. This is a safe initial chronological baseline, not a final validation system.

## Next upgrades

1. Save timestamped bookmaker odds to local CSV or SQLite, including event ID, sportsbook, market, line, odds, captured_at, kickoff, and outcome rules.
2. Add weekly expanding walk-forward training and nested probability calibration.
3. Train a two-team score distribution for spreads/totals and correct handling of pushes and ties.
4. Add player-game stats and usage-based prop models, with explicit injury/lineup data availability timestamps.
5. Compare against no-vig market consensus, evaluate closing-line value and ROI only with authentic pre-kickoff offered prices.

Data source: https://github.com/nflverse/nflreadpy and https://github.com/nflverse/nflverse-data
